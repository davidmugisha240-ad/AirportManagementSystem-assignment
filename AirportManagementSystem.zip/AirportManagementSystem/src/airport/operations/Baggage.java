package airport.operations;

import airport.passengers.Passenger;

// ─── Baggage ──────────────────────────────────────────────────────
public class Baggage {
    public enum BaggageStatus { CHECKED_IN, LOADED, IN_TRANSIT, DELIVERED, LOST }

    private String baggageId;
    private double weight;
    private Passenger owner;
    private BaggageStatus status;

    public Baggage() {}

    public Baggage(String baggageId, double weight, Passenger owner) {
        this.baggageId = baggageId;
        this.weight = weight;
        this.owner = owner;
        this.status = BaggageStatus.CHECKED_IN;
    }

    public String getBaggageId() { return baggageId; }
    public double getWeight() { return weight; }
    public Passenger getOwner() { return owner; }
    public BaggageStatus getStatus() { return status; }
    public void setStatus(BaggageStatus status) { this.status = status; }

    @Override public String toString() {
        return String.format("[Baggage] ID: %s | Owner: %s | Weight: %.1f kg | Status: %s",
                baggageId, owner.getFullName(), weight, status);
    }
}
