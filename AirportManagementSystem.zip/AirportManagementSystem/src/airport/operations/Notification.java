package airport.operations;

import airport.passengers.Passenger;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Notification {
    private String notificationId;
    private String message;
    private Passenger recipient;
    private LocalDateTime date;

    public Notification() {}

    public Notification(String notificationId, String message, Passenger recipient) {
        this.notificationId = notificationId;
        this.message = message;
        this.recipient = recipient;
        this.date = LocalDateTime.now();
    }

    public String getNotificationId() { return notificationId; }
    public String getMessage() { return message; }
    public Passenger getRecipient() { return recipient; }
    public LocalDateTime getDate() { return date; }

    public void send() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        System.out.printf("[NOTIFICATION → %s] %s (sent: %s)%n",
                recipient.getFullName(), message, date.format(fmt));
    }

    @Override public String toString() {
        return String.format("[Notification] ID: %s | To: %s | Message: %s",
                notificationId, recipient.getFullName(), message);
    }
}
