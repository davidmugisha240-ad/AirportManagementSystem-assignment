package airport.operations;

import java.util.ArrayList;
import java.util.List;

// ─── Airport ──────────────────────────────────────────────────────
public class Airport {
    private String airportId;
    private String name;
    private String location;
    private int numberOfTerminals;
    private List<Terminal> terminals = new ArrayList<>();

    public Airport() {}

    public Airport(String airportId, String name, String location, int numberOfTerminals) {
        this.airportId = airportId;
        this.name = name;
        this.location = location;
        this.numberOfTerminals = numberOfTerminals;
    }

    public String getAirportId() { return airportId; }
    public String getName() { return name; }
    public String getLocation() { return location; }
    public int getNumberOfTerminals() { return numberOfTerminals; }
    public List<Terminal> getTerminals() { return terminals; }
    public void addTerminal(Terminal t) { terminals.add(t); }

    @Override public String toString() {
        return String.format("[Airport] ID: %s | Name: %s | Location: %s | Terminals: %d",
                airportId, name, location, numberOfTerminals);
    }
}
