package airport.operations;

import airport.flights.Flight;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

// ─── Schedule ─────────────────────────────────────────────────────
public class Schedule {
    private String scheduleId;
    private Flight flight;
    private Gate gate;
    private LocalDateTime departureTime;

    public Schedule() {}

    public Schedule(String scheduleId, Flight flight, Gate gate, LocalDateTime departureTime) {
        this.scheduleId = scheduleId;
        this.flight = flight;
        this.gate = gate;
        this.departureTime = departureTime;
    }

    public String getScheduleId() { return scheduleId; }
    public Flight getFlight() { return flight; }
    public Gate getGate() { return gate; }
    public LocalDateTime getDepartureTime() { return departureTime; }
    public void setDepartureTime(LocalDateTime t) { this.departureTime = t; }

    @Override public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return String.format("[Schedule] ID: %s | Flight: %s | Gate: %s | Departure: %s",
                scheduleId, flight.getFlightId(), gate.getGateId(), departureTime.format(fmt));
    }
}
