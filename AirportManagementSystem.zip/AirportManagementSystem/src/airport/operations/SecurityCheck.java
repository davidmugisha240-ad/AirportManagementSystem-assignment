package airport.operations;

import airport.passengers.Passenger;

public class SecurityCheck {
    public enum CheckStatus { PENDING, PASSED, FAILED, UNDER_REVIEW }

    private String checkId;
    private Passenger passenger;
    private CheckStatus status;
    private String remarks;

    public SecurityCheck() {}

    public SecurityCheck(String checkId, Passenger passenger) {
        this.checkId = checkId;
        this.passenger = passenger;
        this.status = CheckStatus.PENDING;
        this.remarks = "";
    }

    public String getCheckId() { return checkId; }
    public Passenger getPassenger() { return passenger; }
    public CheckStatus getStatus() { return status; }
    public String getRemarks() { return remarks; }

    public void conductCheck(boolean passed, String remarks) {
        this.status = passed ? CheckStatus.PASSED : CheckStatus.FAILED;
        this.remarks = remarks;
    }

    @Override public String toString() {
        return String.format("[SecurityCheck] ID: %s | Passenger: %s | Status: %s | Remarks: %s",
                checkId, passenger.getFullName(), status, remarks.isEmpty() ? "None" : remarks);
    }
}
