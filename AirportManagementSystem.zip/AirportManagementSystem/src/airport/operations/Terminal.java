package airport.operations;

import java.util.ArrayList;
import java.util.List;

// ─── Terminal ─────────────────────────────────────────────────────
public class Terminal {
    private String terminalId;
    private String name;
    private int capacity;
    private List<Gate> gates = new ArrayList<>();

    public Terminal() {}

    public Terminal(String terminalId, String name, int capacity) {
        this.terminalId = terminalId;
        this.name = name;
        this.capacity = capacity;
    }

    public String getTerminalId() { return terminalId; }
    public String getName() { return name; }
    public int getCapacity() { return capacity; }
    public List<Gate> getGates() { return gates; }
    public void addGate(Gate g) { gates.add(g); }

    @Override public String toString() {
        return String.format("[Terminal] ID: %s | Name: %s | Capacity: %d | Gates: %d",
                terminalId, name, capacity, gates.size());
    }
}
