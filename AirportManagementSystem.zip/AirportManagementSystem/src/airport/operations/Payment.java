package airport.operations;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Payment {
    public enum PaymentStatus { PENDING, COMPLETED, FAILED, REFUNDED }
    public enum PaymentMethod { CREDIT_CARD, DEBIT_CARD, CASH, BANK_TRANSFER, MOBILE_MONEY }

    private String paymentId;
    private double amount;
    private PaymentMethod paymentMethod;
    private PaymentStatus paymentStatus;
    private LocalDateTime paymentDate;

    public Payment() {}

    public Payment(String paymentId, double amount, PaymentMethod paymentMethod) {
        this.paymentId = paymentId;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.paymentStatus = PaymentStatus.PENDING;
        this.paymentDate = LocalDateTime.now();
    }

    public String getPaymentId() { return paymentId; }
    public double getAmount() { return amount; }
    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public PaymentStatus getPaymentStatus() { return paymentStatus; }

    public boolean process() {
        this.paymentStatus = PaymentStatus.COMPLETED;
        return true;
    }

    public String generateReceipt() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return String.format("""
                ╔══════════════════════════════════════════╗
                ║            PAYMENT RECEIPT               ║
                ╠══════════════════════════════════════════╣
                  Payment ID : %s
                  Amount     : $%.2f
                  Method     : %s
                  Status     : %s
                  Date       : %s
                ╚══════════════════════════════════════════╝""",
                paymentId, amount, paymentMethod, paymentStatus, paymentDate.format(fmt));
    }

    @Override public String toString() {
        return String.format("[Payment] ID: %s | Amount: $%.2f | Method: %s | Status: %s",
                paymentId, amount, paymentMethod, paymentStatus);
    }
}
