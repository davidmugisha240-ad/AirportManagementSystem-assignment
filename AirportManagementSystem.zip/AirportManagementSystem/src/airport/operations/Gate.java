package airport.operations;

public class Gate {
    public enum GateStatus { OPEN, CLOSED, BOARDING, DEPARTED }

    private String gateId;
    private Terminal terminal;
    private GateStatus status;

    public Gate() {}

    public Gate(String gateId, Terminal terminal) {
        this.gateId = gateId;
        this.terminal = terminal;
        this.status = GateStatus.OPEN;
    }

    public String getGateId() { return gateId; }
    public Terminal getTerminal() { return terminal; }
    public GateStatus getStatus() { return status; }
    public void setStatus(GateStatus status) { this.status = status; }

    @Override public String toString() {
        return String.format("[Gate] ID: %s | Terminal: %s | Status: %s",
                gateId, terminal.getName(), status);
    }
}
