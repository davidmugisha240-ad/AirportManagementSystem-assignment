package airport.passengers;

import airport.flights.Flight;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Reservation {
    public enum ReservationStatus { PENDING, CONFIRMED, CANCELLED, MODIFIED }

    private String reservationId;
    private Passenger passenger;
    private Flight flight;
    private LocalDateTime bookingDate;
    private ReservationStatus status;

    public Reservation() {}

    public Reservation(String reservationId, Passenger passenger, Flight flight) {
        this.reservationId = reservationId;
        this.passenger = passenger;
        this.flight = flight;
        this.bookingDate = LocalDateTime.now();
        this.status = ReservationStatus.PENDING;
    }

    public String getReservationId() { return reservationId; }
    public Passenger getPassenger() { return passenger; }
    public Flight getFlight() { return flight; }
    public LocalDateTime getBookingDate() { return bookingDate; }
    public ReservationStatus getStatus() { return status; }

    public boolean confirmReservation() {
        if (status == ReservationStatus.CANCELLED) {
            System.out.println("Cannot confirm a cancelled reservation.");
            return false;
        }
        if (!flight.bookSeat()) {
            System.out.println("No available seats on this flight.");
            return false;
        }
        status = ReservationStatus.CONFIRMED;
        return true;
    }

    public boolean cancelReservation() {
        if (status == ReservationStatus.CANCELLED) return false;
        status = ReservationStatus.CANCELLED;
        return true;
    }

    public boolean updateReservation(String field, String value) {
        status = ReservationStatus.MODIFIED;
        return true;
    }

    @Override public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return String.format("[Reservation] %s | Passenger: %s | Flight: %s | Date: %s | Status: %s",
                reservationId, passenger.getFullName(), flight.getFlightId(),
                bookingDate.format(fmt), status);
    }
}
