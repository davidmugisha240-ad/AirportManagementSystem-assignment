package airport.passengers;

import airport.flights.Flight;

public class Ticket {
    public enum ClassType { ECONOMY, BUSINESS, FIRST }

    private String ticketId;
    private Passenger passenger;
    private Flight flight;
    private String seatNumber;
    private ClassType classType;
    private double price;

    public Ticket() {}

    public Ticket(String ticketId, Passenger passenger, Flight flight,
                  String seatNumber, ClassType classType) {
        this.ticketId = ticketId;
        this.passenger = passenger;
        this.flight = flight;
        this.seatNumber = seatNumber;
        this.classType = classType;
        this.price = calculateTicketPrice();
    }

    public String getTicketId() { return ticketId; }
    public Passenger getPassenger() { return passenger; }
    public Flight getFlight() { return flight; }
    public String getSeatNumber() { return seatNumber; }
    public ClassType getClassType() { return classType; }
    public double getPrice() { return price; }

    public double calculateTicketPrice() {
        double base = switch (classType) {
            case ECONOMY  -> 200.0;
            case BUSINESS -> 600.0;
            case FIRST    -> 1200.0;
        };
        // Adjust by flight type
        String type = flight.getFlightType();
        double multiplier = switch (type) {
            case "International" -> 2.5;
            case "Charter"       -> 3.0;
            case "Emergency"     -> 4.0;
            case "Cargo"         -> 1.5;
            default              -> 1.0;
        };
        return base * multiplier;
    }

    public String generateTicketDetails() {
        return String.format("""
                ╔══════════════════════════════════════════╗
                ║              AIRLINE TICKET              ║
                ╠══════════════════════════════════════════╣
                  Ticket ID  : %s
                  Passenger  : %s
                  Passport   : %s
                  Flight     : %s → %s
                  Flight ID  : %s
                  Seat       : %s  |  Class: %s
                  Price      : $%.2f
                ╚══════════════════════════════════════════╝""",
                ticketId, passenger.getFullName(), passenger.getPassportNumber(),
                flight.getDepartureLocation(), flight.getDestination(),
                flight.getFlightId(), seatNumber, classType, price);
    }

    @Override public String toString() {
        return String.format("[Ticket] %s | Passenger: %s | Flight: %s | Seat: %s | Class: %s | Price: $%.2f",
                ticketId, passenger.getFullName(), flight.getFlightId(), seatNumber, classType, price);
    }
}
