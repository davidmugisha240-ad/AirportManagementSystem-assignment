package airport.passengers;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BoardingPass {
    private String boardingPassId;
    private Ticket ticket;
    private String gateNumber;
    private LocalDateTime boardingTime;

    public BoardingPass() {}

    public BoardingPass(String boardingPassId, Ticket ticket, String gateNumber, LocalDateTime boardingTime) {
        this.boardingPassId = boardingPassId;
        this.ticket = ticket;
        this.gateNumber = gateNumber;
        this.boardingTime = boardingTime;
    }

    public String getBoardingPassId() { return boardingPassId; }
    public Ticket getTicket() { return ticket; }
    public String getGateNumber() { return gateNumber; }
    public LocalDateTime getBoardingTime() { return boardingTime; }

    public String generateBoardingPassDisplay() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return String.format("""
                ╔══════════════════════════════════════════╗
                ║            ✈  BOARDING PASS  ✈           ║
                ╠══════════════════════════════════════════╣
                  BP ID      : %s
                  Passenger  : %s
                  From       : %s
                  To         : %s
                  Flight     : %s  |  Seat: %s
                  Class      : %s
                  Gate       : %s
                  Board Time : %s
                  Depart     : %s
                ╚══════════════════════════════════════════╝""",
                boardingPassId,
                ticket.getPassenger().getFullName(),
                ticket.getFlight().getDepartureLocation(),
                ticket.getFlight().getDestination(),
                ticket.getFlight().getFlightId(),
                ticket.getSeatNumber(),
                ticket.getClassType(),
                gateNumber,
                boardingTime.format(fmt),
                ticket.getFlight().getDepartureTime().format(fmt));
    }

    @Override public String toString() {
        return String.format("[BoardingPass] %s | Flight: %s | Gate: %s | Seat: %s",
                boardingPassId, ticket.getFlight().getFlightId(),
                gateNumber, ticket.getSeatNumber());
    }
}
