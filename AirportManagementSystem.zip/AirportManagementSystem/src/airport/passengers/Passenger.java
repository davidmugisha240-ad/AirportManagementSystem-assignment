package airport.passengers;

import airport.flights.Flight;

// ─── Passenger ────────────────────────────────────────────────────
public class Passenger {
    private String passengerId;
    private String fullName;
    private String passportNumber;
    private String nationality;
    private String phoneNumber;

    public Passenger() {}

    public Passenger(String passengerId, String fullName, String passportNumber,
                     String nationality, String phoneNumber) {
        this.passengerId = passengerId;
        this.fullName = fullName;
        this.passportNumber = passportNumber;
        this.nationality = nationality;
        this.phoneNumber = phoneNumber;
    }

    public String getPassengerId() { return passengerId; }
    public void setPassengerId(String passengerId) { this.passengerId = passengerId; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getPassportNumber() { return passportNumber; }
    public void setPassportNumber(String passportNumber) { this.passportNumber = passportNumber; }
    public String getNationality() { return nationality; }
    public void setNationality(String nationality) { this.nationality = nationality; }
    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    @Override public String toString() {
        return String.format("[Passenger] ID: %s | Name: %s | Passport: %s | Nationality: %s | Phone: %s",
                passengerId, fullName, passportNumber, nationality, phoneNumber);
    }
}
