package airport.flights;

import java.time.LocalDateTime;

public class FlightFactory {

    public enum FlightType { DOMESTIC, INTERNATIONAL, CARGO, CHARTER, EMERGENCY }

    public static Flight createFlight(FlightType type, String flightId, String airlineName,
                                      String departure, String destination,
                                      LocalDateTime depTime, LocalDateTime arrTime, int capacity) {
        return switch (type) {
            case DOMESTIC      -> new DomesticFlight(flightId, airlineName, departure, destination, depTime, arrTime, capacity, "DOM");
            case INTERNATIONAL -> new InternationalFlight(flightId, airlineName, departure, destination, depTime, arrTime, capacity, true, "REQUIRED");
            case CARGO         -> new CargoFlight(flightId, airlineName, departure, destination, depTime, arrTime, capacity, 50000);
            case CHARTER       -> new CharterFlight(flightId, airlineName, departure, destination, depTime, arrTime, capacity, "VIP Client");
            case EMERGENCY     -> new EmergencyFlight(flightId, airlineName, departure, destination, depTime, arrTime, capacity, 3);
        };
    }

    // Polymorphic display
    public static void displayFlightInfo(Flight flight) {
        System.out.println("  Type     : " + flight.getFlightType());
        System.out.println("  Details  : " + flight);
        System.out.println("  Duration : " + flight.calculateFlightDuration());
        System.out.println("  Seats    : " + (flight.hasAvailableSeats() ? "Available" : "FULL"));
    }
}
