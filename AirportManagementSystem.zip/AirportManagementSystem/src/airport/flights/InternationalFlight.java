package airport.flights;

import java.time.LocalDateTime;

// ─── InternationalFlight ──────────────────────────────────────────
public class InternationalFlight extends Flight {
    private boolean passportRequired;
    private String visaRequirement;

    public InternationalFlight() { super(); this.passportRequired = true; this.visaRequirement = "REQUIRED"; }

    public InternationalFlight(String flightId, String airlineName, String departure,
                               String destination, LocalDateTime depTime, LocalDateTime arrTime,
                               int capacity, boolean passportRequired, String visaRequirement) {
        super(flightId, airlineName, departure, destination, depTime, arrTime, capacity);
        this.passportRequired = passportRequired;
        this.visaRequirement = visaRequirement;
    }

    public boolean isPassportRequired() { return passportRequired; }
    public String getVisaRequirement() { return visaRequirement; }
    public void setVisaRequirement(String v) { this.visaRequirement = v; }

    @Override public String getFlightType() { return "International"; }
    @Override public String calculateFlightDuration() { return "INTL:" + super.calculateFlightDuration(); }
    @Override public String toString() {
        return super.toString() + " | Passport: " + (passportRequired ? "YES" : "NO") + " | Visa: " + visaRequirement;
    }
}
