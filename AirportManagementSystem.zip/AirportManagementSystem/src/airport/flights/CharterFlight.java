package airport.flights;

import java.time.LocalDateTime;

public class CharterFlight extends Flight {
    private String privateClientName;

    public CharterFlight() { super(); this.privateClientName = "Private Client"; }

    public CharterFlight(String flightId, String airlineName, String departure,
                         String destination, LocalDateTime depTime, LocalDateTime arrTime,
                         int capacity, String privateClientName) {
        super(flightId, airlineName, departure, destination, depTime, arrTime, capacity);
        this.privateClientName = privateClientName;
    }

    public String getPrivateClientName() { return privateClientName; }
    public void setPrivateClientName(String name) { this.privateClientName = name; }

    @Override public String getFlightType() { return "Charter"; }
    @Override public String calculateFlightDuration() { return "CHARTER:" + super.calculateFlightDuration(); }
    @Override public String toString() {
        return super.toString() + " | Client: " + privateClientName;
    }
}
