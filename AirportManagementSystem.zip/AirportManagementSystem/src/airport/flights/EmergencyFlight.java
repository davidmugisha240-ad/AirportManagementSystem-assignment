package airport.flights;

import java.time.LocalDateTime;

public class EmergencyFlight extends Flight {
    private int emergencyLevel; // 1-5, 5 being most critical

    public EmergencyFlight() { super(); this.emergencyLevel = 1; }

    public EmergencyFlight(String flightId, String airlineName, String departure,
                           String destination, LocalDateTime depTime, LocalDateTime arrTime,
                           int capacity, int emergencyLevel) {
        super(flightId, airlineName, departure, destination, depTime, arrTime, capacity);
        this.emergencyLevel = Math.max(1, Math.min(5, emergencyLevel));
    }

    public int getEmergencyLevel() { return emergencyLevel; }
    public void setEmergencyLevel(int level) { this.emergencyLevel = Math.max(1, Math.min(5, level)); }

    @Override public String getFlightType() { return "Emergency"; }
    @Override public String calculateFlightDuration() { return "EMRG:" + super.calculateFlightDuration(); }
    @Override public boolean hasAvailableSeats() { return true; } // Emergency flights override capacity rules
    @Override public String toString() {
        return super.toString() + " | Emergency Level: " + emergencyLevel + "/5";
    }
}
