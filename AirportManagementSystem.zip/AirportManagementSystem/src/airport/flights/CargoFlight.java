package airport.flights;

import java.time.LocalDateTime;

public class CargoFlight extends Flight {
    private double cargoWeightLimit;
    private double currentCargoWeight;

    public CargoFlight() { super(); this.cargoWeightLimit = 50000; this.currentCargoWeight = 0; }

    public CargoFlight(String flightId, String airlineName, String departure,
                       String destination, LocalDateTime depTime, LocalDateTime arrTime,
                       int capacity, double cargoWeightLimit) {
        super(flightId, airlineName, departure, destination, depTime, arrTime, capacity);
        this.cargoWeightLimit = cargoWeightLimit;
        this.currentCargoWeight = 0;
    }

    public double getCargoWeightLimit() { return cargoWeightLimit; }
    public void setCargoWeightLimit(double w) { this.cargoWeightLimit = w; }
    public double getCurrentCargoWeight() { return currentCargoWeight; }

    public boolean addCargo(double weight) {
        if (currentCargoWeight + weight <= cargoWeightLimit) {
            currentCargoWeight += weight; return true;
        }
        return false;
    }

    @Override public String getFlightType() { return "Cargo"; }
    @Override public String calculateFlightDuration() { return "CARGO:" + super.calculateFlightDuration(); }
    @Override public String toString() {
        return super.toString() + String.format(" | Cargo: %.1f/%.1f kg", currentCargoWeight, cargoWeightLimit);
    }
}
