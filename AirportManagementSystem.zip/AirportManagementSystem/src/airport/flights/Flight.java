package airport.flights;

import java.time.LocalDateTime;
import java.time.Duration;
import java.time.format.DateTimeFormatter;

public class Flight {
    private String flightId;
    private String airlineName;
    private String departureLocation;
    private String destination;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
    private int capacity;
    private int bookedSeats;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public Flight() {
        this.flightId = "FL000";
        this.airlineName = "Unknown Airline";
        this.departureLocation = "Unknown";
        this.destination = "Unknown";
        this.departureTime = LocalDateTime.now();
        this.arrivalTime = LocalDateTime.now().plusHours(2);
        this.capacity = 100;
        this.bookedSeats = 0;
    }

    public Flight(String flightId, String airlineName, String departureLocation,
                  String destination, LocalDateTime departureTime, LocalDateTime arrivalTime, int capacity) {
        this.flightId = flightId;
        this.airlineName = airlineName;
        this.departureLocation = departureLocation;
        this.destination = destination;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.capacity = capacity;
        this.bookedSeats = 0;
    }

    // Getters & Setters
    public String getFlightId() { return flightId; }
    public void setFlightId(String flightId) { this.flightId = flightId; }
    public String getAirlineName() { return airlineName; }
    public void setAirlineName(String airlineName) { this.airlineName = airlineName; }
    public String getDepartureLocation() { return departureLocation; }
    public void setDepartureLocation(String departureLocation) { this.departureLocation = departureLocation; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public LocalDateTime getDepartureTime() { return departureTime; }
    public void setDepartureTime(LocalDateTime departureTime) { this.departureTime = departureTime; }
    public LocalDateTime getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(LocalDateTime arrivalTime) { this.arrivalTime = arrivalTime; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public int getBookedSeats() { return bookedSeats; }
    public void setBookedSeats(int bookedSeats) { this.bookedSeats = bookedSeats; }

    public boolean hasAvailableSeats() { return bookedSeats < capacity; }
    public boolean bookSeat() {
        if (hasAvailableSeats()) { bookedSeats++; return true; }
        return false;
    }

    public String calculateFlightDuration() {
        Duration d = Duration.between(departureTime, arrivalTime);
        long hours = d.toHours();
        long minutes = d.toMinutesPart();
        return hours + "h " + minutes + "m";
    }

    public String getFlightType() { return "Standard Flight"; }

    @Override
    public String toString() {
        return String.format("[%s] %s | %s → %s | Dep: %s | Arr: %s | Seats: %d/%d | Duration: %s",
                getFlightType(), flightId, departureLocation, destination,
                departureTime.format(FMT), arrivalTime.format(FMT),
                bookedSeats, capacity, calculateFlightDuration());
    }
}
