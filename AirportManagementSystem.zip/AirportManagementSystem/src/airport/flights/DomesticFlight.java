package airport.flights;

import java.time.LocalDateTime;

// ─── DomesticFlight ───────────────────────────────────────────────
public class DomesticFlight extends Flight {
    private String regionCode;

    public DomesticFlight() { super(); this.regionCode = "DOM"; }

    public DomesticFlight(String flightId, String airlineName, String departure,
                          String destination, LocalDateTime depTime, LocalDateTime arrTime,
                          int capacity, String regionCode) {
        super(flightId, airlineName, departure, destination, depTime, arrTime, capacity);
        this.regionCode = regionCode;
    }

    public String getRegionCode() { return regionCode; }
    public void setRegionCode(String regionCode) { this.regionCode = regionCode; }

    @Override public String getFlightType() { return "Domestic"; }
    @Override public String calculateFlightDuration() { return "DOM:" + super.calculateFlightDuration(); }
    @Override public String toString() {
        return super.toString() + " | Region: " + regionCode;
    }
}
