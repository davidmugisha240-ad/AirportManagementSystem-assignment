package airport.core;

public interface Trackable {
    String trackStatus(String entityId);
    void updateLocation(String newLocation);
    String getCurrentLocation();
}
