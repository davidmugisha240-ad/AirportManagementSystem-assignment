package airport.core;

public interface Payable {
    boolean processPayment(double amount, String method);
    double calculateAmount(String itemId);
    String generateReceipt(String paymentId);
}
