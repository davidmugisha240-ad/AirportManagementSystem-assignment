package airport.core;

public interface Reservable {
    String createReservation(String passengerId, String flightId);
    boolean cancelReservation(String reservationId);
    boolean modifyReservation(String reservationId, String field, String newValue);
}
