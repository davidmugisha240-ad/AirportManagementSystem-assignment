package airport.core;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public abstract class AirportEntity {
    private String entityId;
    private String name;
    private String status;
    private LocalDateTime createdDate;
    private LocalDateTime lastUpdated;

    // Default constructor
    public AirportEntity() {
        this.entityId = "UNKNOWN";
        this.name = "Unnamed";
        this.status = "INACTIVE";
        this.createdDate = LocalDateTime.now();
        this.lastUpdated = LocalDateTime.now();
    }

    // Parameterized constructor
    public AirportEntity(String entityId, String name, String status) {
        this.entityId = entityId;
        this.name = name;
        this.status = status;
        this.createdDate = LocalDateTime.now();
        this.lastUpdated = LocalDateTime.now();
    }

    // Getters and Setters
    public String getEntityId() { return entityId; }
    public void setEntityId(String entityId) { this.entityId = entityId; this.lastUpdated = LocalDateTime.now(); }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; this.lastUpdated = LocalDateTime.now(); }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; this.lastUpdated = LocalDateTime.now(); }

    public LocalDateTime getCreatedDate() { return createdDate; }
    public LocalDateTime getLastUpdated() { return lastUpdated; }

    // Abstract methods
    public abstract boolean validateEntity();
    public abstract void activateEntity();
    public abstract void deactivateEntity();
    public abstract void updateDetails(String field, String value);
    public abstract String generateReport();
    public abstract void logActivity(String activity);
    public abstract String checkStatus();
    public abstract void archiveEntity();
    public abstract void restoreEntity();
    public abstract void displaySummary();

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return String.format("[Entity] ID: %s | Name: %s | Status: %s | Created: %s",
                entityId, name, status, createdDate.format(fmt));
    }
}
