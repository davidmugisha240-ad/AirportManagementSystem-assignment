package airport.core;

import java.util.ArrayList;
import java.util.List;

public class AirportManager extends AirportEntity implements Reservable, Payable, Trackable {
    private String airportName;
    private int terminalNumber;
    private String managerName;
    private String currentLocation;
    private List<String> activityLog = new ArrayList<>();

    public AirportManager() {
        super();
        this.airportName = "Unknown Airport";
        this.terminalNumber = 1;
        this.managerName = "Unknown Manager";
        this.currentLocation = "Main Office";
    }

    public AirportManager(String entityId, String name, String airportName, int terminalNumber, String managerName) {
        super(entityId, name, "ACTIVE");
        this.airportName = airportName;
        this.terminalNumber = terminalNumber;
        this.managerName = managerName;
        this.currentLocation = "Terminal " + terminalNumber;
    }

    // Getters & Setters
    public String getAirportName() { return airportName; }
    public void setAirportName(String airportName) { this.airportName = airportName; }
    public int getTerminalNumber() { return terminalNumber; }
    public void setTerminalNumber(int terminalNumber) { this.terminalNumber = terminalNumber; }
    public String getManagerName() { return managerName; }
    public void setManagerName(String managerName) { this.managerName = managerName; }

    // AirportEntity abstract method implementations
    @Override public boolean validateEntity() {
        return airportName != null && !airportName.isEmpty() && managerName != null && !managerName.isEmpty();
    }
    @Override public void activateEntity() { setStatus("ACTIVE"); logActivity("Entity activated"); }
    @Override public void deactivateEntity() { setStatus("INACTIVE"); logActivity("Entity deactivated"); }
    @Override public void updateDetails(String field, String value) {
        switch (field.toLowerCase()) {
            case "airportname" -> airportName = value;
            case "managername" -> managerName = value;
            default -> System.out.println("Unknown field: " + field);
        }
        logActivity("Updated field: " + field);
    }
    @Override public String generateReport() {
        return String.format("=== Manager Report ===\nManager: %s\nAirport: %s\nTerminal: %d\nStatus: %s",
                managerName, airportName, terminalNumber, getStatus());
    }
    @Override public void logActivity(String activity) { activityLog.add("[LOG] " + activity); }
    @Override public String checkStatus() { return "Manager Status: " + getStatus(); }
    @Override public void archiveEntity() { setStatus("ARCHIVED"); logActivity("Entity archived"); }
    @Override public void restoreEntity() { setStatus("ACTIVE"); logActivity("Entity restored"); }
    @Override public void displaySummary() {
        System.out.println("Manager: " + managerName + " | Airport: " + airportName + " | Terminal: " + terminalNumber);
    }

    // Reservable
    @Override public String createReservation(String passengerId, String flightId) {
        String resId = "RES-" + System.currentTimeMillis();
        logActivity("Reservation created: " + resId);
        return resId;
    }
    @Override public boolean cancelReservation(String reservationId) {
        logActivity("Reservation cancelled: " + reservationId); return true;
    }
    @Override public boolean modifyReservation(String reservationId, String field, String newValue) {
        logActivity("Reservation " + reservationId + " modified: " + field + " -> " + newValue); return true;
    }

    // Payable
    @Override public boolean processPayment(double amount, String method) {
        logActivity("Payment processed: $" + amount + " via " + method); return true;
    }
    @Override public double calculateAmount(String itemId) { return 100.0; }
    @Override public String generateReceipt(String paymentId) {
        return "RECEIPT-" + paymentId + " | Airport: " + airportName;
    }

    // Trackable
    @Override public String trackStatus(String entityId) { return "Tracking: " + entityId + " | Status: Active"; }
    @Override public void updateLocation(String newLocation) { this.currentLocation = newLocation; }
    @Override public String getCurrentLocation() { return currentLocation; }

    @Override public String toString() {
        return String.format("[AirportManager] %s | Airport: %s | Terminal: %d | Manager: %s",
                getEntityId(), airportName, terminalNumber, managerName);
    }
}
