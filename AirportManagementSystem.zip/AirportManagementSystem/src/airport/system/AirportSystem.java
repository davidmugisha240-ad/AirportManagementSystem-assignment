package airport.system;

import airport.core.AirportManager;
import airport.flights.*;
import airport.passengers.*;
import airport.operations.*;
import airport.staff.*;

import java.time.LocalDateTime;
import java.util.*;

public class AirportSystem {

    // ── In-memory stores ──────────────────────────────────────────
    private static final List<Flight>      flights      = new ArrayList<>();
    private static final List<Passenger>   passengers   = new ArrayList<>();
    private static final List<Reservation> reservations = new ArrayList<>();
    private static final List<Ticket>      tickets      = new ArrayList<>();
    private static final List<Payment>     payments     = new ArrayList<>();

    private static final Scanner sc = new Scanner(System.in);
    private static int idCounter = 1000;

    // ── Entry point ───────────────────────────────────────────────
    public static void main(String[] args) {
        seedData();
        printBanner();

        boolean running = true;
        while (running) {
            printMainMenu();
            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1" -> bookFlight();
                case "2" -> viewAllFlights();
                case "3" -> viewMyBookings();
                case "4" -> cancelReservation();
                case "5" -> viewReports();
                case "6" -> demonstrateOOP();
                case "0" -> { System.out.println("\n  Thank you for using AirportMS. Safe travels! ✈\n"); running = false; }
                default  -> System.out.println("  ⚠  Invalid choice. Please try again.");
            }
        }
    }

    // ── Main menu ─────────────────────────────────────────────────
    static void printMainMenu() {
        System.out.println("""

                ╔══════════════════════════════════════════╗
                ║        ✈  AIRPORT MANAGEMENT SYSTEM      ║
                ╠══════════════════════════════════════════╣
                ║  1. Book a Flight                        ║
                ║  2. View All Flights                     ║
                ║  3. View My Bookings                     ║
                ║  4. Cancel Reservation                   ║
                ║  5. View Reports                         ║
                ║  6. OOP Demo (Polymorphism + Factory)    ║
                ║  0. Exit                                 ║
                ╚══════════════════════════════════════════╝
                Enter choice:""");
    }

    // ── 1. Book a Flight ─────────────────────────────────────────
    static void bookFlight() {
        System.out.println("\n  ═══ BOOK A FLIGHT ═══");

        // ── Passenger details ─────────────────────────────────────
        String fullName = promptValidated("  Full Name         : ", v -> InputValidator.validateName(v, "Full Name"));
        String passport  = promptValidated("  Passport Number   : ", InputValidator::validatePassportNumber);
        String nationality = promptValidated("  Nationality       : ", v -> InputValidator.validateName(v, "Nationality"));
        String phone     = promptValidated("  Phone Number      : ", InputValidator::validatePhone);

        // Check duplicate passport
        boolean duplicate = passengers.stream().anyMatch(p -> p.getPassportNumber().equals(passport));
        if (duplicate) {
            System.out.println("  ⚠  Passport already registered. Reusing existing passenger record.");
        }

        Passenger passenger = passengers.stream()
                .filter(p -> p.getPassportNumber().equals(passport))
                .findFirst()
                .orElseGet(() -> {
                    Passenger np = new Passenger("PSG" + (++idCounter), fullName, passport, nationality, phone);
                    passengers.add(np);
                    return np;
                });

        // ── Flight selection ──────────────────────────────────────
        System.out.println("\n  ═══ AVAILABLE FLIGHTS ═══");
        List<Flight> available = flights.stream().filter(Flight::hasAvailableSeats).toList();
        if (available.isEmpty()) { System.out.println("  No available flights at the moment."); return; }
        for (int i = 0; i < available.size(); i++) {
            System.out.printf("  [%d] %s%n", i + 1, available.get(i));
        }

        int fi = Integer.parseInt(promptValidated(
                "\n  Select flight (1-" + available.size() + "): ",
                v -> String.valueOf(Integer.parseInt(InputValidator.validateFlightChoice(v, available.size()))))) - 1;
        Flight selectedFlight = available.get(fi);

        // Check overbooking
        if (!selectedFlight.hasAvailableSeats()) {
            System.out.println("  ⚠  Sorry, this flight is now fully booked.");
            return;
        }

        // ── Seat & Class ──────────────────────────────────────────
        String seat      = promptValidated("  Seat Number (e.g. A1): ", InputValidator::validateSeatNumber);
        String classStr  = promptValidated("  Class (1-Economy / 2-Business / 3-First): ", InputValidator::validateClassType);
        Ticket.ClassType classType = Ticket.ClassType.valueOf(classStr);

        // ── Create objects ────────────────────────────────────────
        String resId  = "RES" + (++idCounter);
        String tktId  = "TKT" + (++idCounter);
        String bpId   = "BP"  + (++idCounter);
        String payId  = "PAY" + (++idCounter);

        Reservation res = new Reservation(resId, passenger, selectedFlight);
        if (!res.confirmReservation()) { System.out.println("  ⚠  Reservation failed."); return; }
        reservations.add(res);

        Ticket ticket = new Ticket(tktId, passenger, selectedFlight, seat, classType);
        tickets.add(ticket);

        // ── Payment ───────────────────────────────────────────────
        System.out.printf("%n  Ticket Price: $%.2f%n", ticket.getPrice());
        String payMethod = promptValidated(
                "  Payment Method (1-Credit / 2-Debit / 3-Cash / 4-Bank / 5-Mobile): ",
                InputValidator::validatePaymentMethod);

        Payment payment = new Payment(payId, ticket.getPrice(), Payment.PaymentMethod.valueOf(payMethod));
        payment.process();
        payments.add(payment);

        // ── Boarding pass ─────────────────────────────────────────
        BoardingPass bp = new BoardingPass(bpId, ticket, "G" + (1 + new Random().nextInt(10)),
                selectedFlight.getDepartureTime().minusMinutes(45));

        // ── Notification ──────────────────────────────────────────
        Notification notif = new Notification("NOT" + (++idCounter),
                "Your booking " + resId + " for flight " + selectedFlight.getFlightId() + " is confirmed!", passenger);

        // ── Security check ────────────────────────────────────────
        SecurityCheck sec = new SecurityCheck("SEC" + (++idCounter), passenger);
        sec.conductCheck(true, "All clear");

        // ── Baggage ───────────────────────────────────────────────
        String bagWeightStr = promptValidated("  Baggage Weight (kg): ", v -> String.valueOf(InputValidator.validatePositiveDouble(v, "Baggage Weight")));
        double bagWeight = Double.parseDouble(bagWeightStr);
        Baggage baggage = new Baggage("BAG" + (++idCounter), bagWeight, passenger);

        // ── Output ────────────────────────────────────────────────
        System.out.println("\n  ✅  BOOKING SUCCESSFUL!");
        System.out.println(ticket.generateTicketDetails());
        System.out.println(bp.generateBoardingPassDisplay());
        System.out.println(payment.generateReceipt());
        System.out.println();
        notif.send();
        System.out.println("  " + sec);
        System.out.println("  " + baggage);
    }

    // ── 2. View All Flights ───────────────────────────────────────
    static void viewAllFlights() {
        System.out.println("\n  ═══ ALL FLIGHTS ═══");
        if (flights.isEmpty()) { System.out.println("  No flights available."); return; }
        flights.forEach(f -> System.out.println("  " + f));
    }

    // ── 3. View My Bookings ───────────────────────────────────────
    static void viewMyBookings() {
        System.out.println("\n  ═══ VIEW MY BOOKINGS ═══");
        String passport = promptValidated("  Enter your Passport Number: ", InputValidator::validatePassportNumber);
        List<Reservation> mine = reservations.stream()
                .filter(r -> r.getPassenger().getPassportNumber().equals(passport)).toList();
        if (mine.isEmpty()) { System.out.println("  No bookings found for this passport."); return; }
        mine.forEach(r -> System.out.println("  " + r));
    }

    // ── 4. Cancel Reservation ─────────────────────────────────────
    static void cancelReservation() {
        System.out.println("\n  ═══ CANCEL RESERVATION ═══");
        String resId = promptValidated("  Reservation ID: ", v -> InputValidator.validateNonEmpty(v, "Reservation ID"));
        reservations.stream()
                .filter(r -> r.getReservationId().equals(resId))
                .findFirst()
                .ifPresentOrElse(r -> {
                    if (r.cancelReservation()) System.out.println("  ✅  Reservation " + resId + " cancelled.");
                    else System.out.println("  ⚠  Already cancelled.");
                }, () -> System.out.println("  ⚠  Reservation not found: " + resId));
    }

    // ── 5. Reports ────────────────────────────────────────────────
    static void viewReports() {
        System.out.println("""

                  ═══ REPORTS MENU ═══
                  1. Daily Flights
                  2. Passenger Statistics
                  3. Revenue Report
                  4. Delays Report
                  Enter choice:""");
        String c = sc.nextLine().trim();
        switch (c) {
            case "1" -> System.out.println(ReportGenerator.generateDailyFlightsReport(flights));
            case "2" -> System.out.println(ReportGenerator.generatePassengerStatisticsReport(reservations));
            case "3" -> System.out.println(ReportGenerator.generateRevenueReport(tickets));
            case "4" -> System.out.println(ReportGenerator.generateDelaysReport(flights));
            default  -> System.out.println("  Invalid report choice.");
        }
    }

    // ── 6. OOP Demo ───────────────────────────────────────────────
    static void demonstrateOOP() {
        System.out.println("\n  ═══ OOP DEMONSTRATION ═══");

        // Polymorphism via FlightFactory
        System.out.println("\n  [1] FlightFactory Polymorphism:");
        Flight[] demo = {
            FlightFactory.createFlight(FlightFactory.FlightType.DOMESTIC,      "FL900", "RwandAir", "Kigali", "Nairobi",    LocalDateTime.now().plusHours(2), LocalDateTime.now().plusHours(4), 120),
            FlightFactory.createFlight(FlightFactory.FlightType.INTERNATIONAL, "FL901", "KLM",      "Kigali", "Amsterdam",  LocalDateTime.now().plusHours(5), LocalDateTime.now().plusHours(13), 200),
            FlightFactory.createFlight(FlightFactory.FlightType.CARGO,         "FL902", "FedEx",    "Kigali", "Dubai",      LocalDateTime.now().plusHours(1), LocalDateTime.now().plusHours(9), 10),
            FlightFactory.createFlight(FlightFactory.FlightType.CHARTER,       "FL903", "PrivateAir","Kigali","London",     LocalDateTime.now().plusHours(3), LocalDateTime.now().plusHours(11), 20),
            FlightFactory.createFlight(FlightFactory.FlightType.EMERGENCY,     "FL904", "MedAir",   "Kigali", "Kampala",    LocalDateTime.now().plusMinutes(30), LocalDateTime.now().plusHours(2), 15)
        };
        for (Flight f : demo) {
            System.out.println("\n  --- " + f.getFlightType() + " ---");
            FlightFactory.displayFlightInfo(f);
        }

        // AirportManager (extends AirportEntity, implements 3 interfaces)
        System.out.println("\n\n  [2] AirportManager (AirportEntity + Reservable + Payable + Trackable):");
        AirportManager mgr = new AirportManager("MGR001", "Kigali Intl Manager", "Kigali International Airport", 2, "Jane Mutesi");
        mgr.displaySummary();
        System.out.println("  " + mgr.generateReport());
        System.out.println("  Reservation: " + mgr.createReservation("PSG001", "FL001"));
        System.out.println("  Receipt    : " + mgr.generateReceipt("PAY001"));
        System.out.println("  Location   : " + mgr.getCurrentLocation());

        // Staff polymorphism
        System.out.println("\n\n  [3] Staff Polymorphism:");
        List<Staff> staffList = List.of(
            new Pilot("ST01", "Capt. Eric Habimana", 8000, 12000),
            new CabinCrew("ST02", "Alice Uwimana", 3000, List.of("English", "French", "Kinyarwanda")),
            new GroundStaff("ST03", "Bob Nkurunziza", 1800, "Baggage Handling"),
            new SecurityOfficer("ST04", "Denis Mugabo", 2500, 4),
            new MaintenanceStaff("ST05", "Frank Uwase", 2200, "Avionics")
        );
        staffList.forEach(s -> System.out.println("  " + s.getRoleDetails() + " → " + s));

        System.out.println("\n  ✅  OOP Demo complete.");
    }

    // ── Helpers ───────────────────────────────────────────────────
    @FunctionalInterface interface Validator { String validate(String input); }

    static String promptValidated(String prompt, Validator validator) {
        while (true) {
            System.out.print(prompt);
            String input = sc.nextLine();
            try { return validator.validate(input); }
            catch (IllegalArgumentException e) { System.out.println("  " + e.getMessage()); }
        }
    }

    static void printBanner() {
        System.out.println("""
                ╔══════════════════════════════════════════════════════╗
                ║                                                      ║
                ║       ✈   AIRPORT MANAGEMENT SYSTEM v1.0  ✈         ║
                ║          Advanced OOP Java Project                   ║
                ║                                                      ║
                ╚══════════════════════════════════════════════════════╝
                """);
    }

    // ── Seed sample data ──────────────────────────────────────────
    static void seedData() {
        LocalDateTime now = LocalDateTime.now();
        flights.add(new DomesticFlight(     "FL001", "RwandAir",   "Kigali",  "Nairobi",    now.plusHours(2),  now.plusHours(4),   150, "EA"));
        flights.add(new DomesticFlight(     "FL002", "Kenya Airways","Nairobi","Kampala",    now.plusHours(3),  now.plusHours(4),    80, "EA"));
        flights.add(new InternationalFlight("FL003", "KLM",         "Kigali",  "Amsterdam",  now.plusHours(6),  now.plusHours(14),  280, true, "REQUIRED"));
        flights.add(new InternationalFlight("FL004", "Ethiopian Air","Kigali",  "Dubai",      now.plusHours(5),  now.plusHours(11),  320, true, "REQUIRED"));
        flights.add(new CargoFlight(        "FL005", "DHL Cargo",   "Kigali",  "Johannesburg",now.plusHours(1), now.plusHours(5),    20, 80000));
        flights.add(new CharterFlight(      "FL006", "PrivateAir",  "Kigali",  "London",     now.plusHours(7),  now.plusHours(15),   30, "VIP Delegation"));
        flights.add(new EmergencyFlight(    "FL007", "MedEvac",     "Kigali",  "Kampala",    now.plusMinutes(45),now.plusHours(2),   10, 5));
    }
}
