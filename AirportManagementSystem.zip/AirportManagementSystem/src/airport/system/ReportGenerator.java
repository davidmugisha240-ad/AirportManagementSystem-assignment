package airport.system;

import airport.flights.Flight;
import airport.passengers.Reservation;
import airport.passengers.Ticket;
import airport.operations.Payment;

import java.time.LocalDate;
import java.util.List;

public class ReportGenerator {

    public static String generateDailyFlightsReport(List<Flight> flights) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n╔══════════════════════════════════════════════════════╗\n");
        sb.append("║              DAILY FLIGHTS REPORT                   ║\n");
        sb.append("║              Date: ").append(LocalDate.now()).append("                       ║\n");
        sb.append("╠══════════════════════════════════════════════════════╣\n");
        if (flights.isEmpty()) {
            sb.append("  No flights scheduled today.\n");
        } else {
            for (Flight f : flights) {
                sb.append("  ").append(f).append("\n");
            }
        }
        sb.append("  Total Flights: ").append(flights.size()).append("\n");
        sb.append("╚══════════════════════════════════════════════════════╝\n");
        return sb.toString();
    }

    public static String generatePassengerStatisticsReport(List<Reservation> reservations) {
        long confirmed = reservations.stream()
                .filter(r -> r.getStatus() == Reservation.ReservationStatus.CONFIRMED).count();
        long cancelled = reservations.stream()
                .filter(r -> r.getStatus() == Reservation.ReservationStatus.CANCELLED).count();

        return String.format("""
                ╔══════════════════════════════════════════════════════╗
                ║           PASSENGER STATISTICS REPORT                ║
                ╠══════════════════════════════════════════════════════╣
                  Total Reservations : %d
                  Confirmed          : %d
                  Cancelled          : %d
                  Pending            : %d
                ╚══════════════════════════════════════════════════════╝
                """, reservations.size(), confirmed, cancelled,
                reservations.size() - confirmed - cancelled);
    }

    public static String generateRevenueReport(List<Ticket> tickets) {
        double total = tickets.stream().mapToDouble(Ticket::getPrice).sum();
        long economy  = tickets.stream().filter(t -> t.getClassType() == Ticket.ClassType.ECONOMY).count();
        long business = tickets.stream().filter(t -> t.getClassType() == Ticket.ClassType.BUSINESS).count();
        long first    = tickets.stream().filter(t -> t.getClassType() == Ticket.ClassType.FIRST).count();

        return String.format("""
                ╔══════════════════════════════════════════════════════╗
                ║                  REVENUE REPORT                      ║
                ╠══════════════════════════════════════════════════════╣
                  Total Revenue      : $%.2f
                  Economy Tickets    : %d
                  Business Tickets   : %d
                  First Class Tickets: %d
                  Total Tickets Sold : %d
                ╚══════════════════════════════════════════════════════╝
                """, total, economy, business, first, tickets.size());
    }

    public static String generateDelaysReport(List<Flight> flights) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n╔══════════════════════════════════════════════════════╗\n");
        sb.append("║                  DELAYS REPORT                      ║\n");
        sb.append("╠══════════════════════════════════════════════════════╣\n");
        sb.append("  No delays recorded (all flights on schedule).\n");
        sb.append("╚══════════════════════════════════════════════════════╝\n");
        return sb.toString();
    }
}
