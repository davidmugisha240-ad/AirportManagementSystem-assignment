package airport.system;

public class InputValidator {

    // ── String checks ──────────────────────────────────────────────
    public static boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    public static String validateNonEmpty(String value, String fieldName) {
        if (isNullOrEmpty(value)) {
            throw new IllegalArgumentException("ERROR: '" + fieldName + "' cannot be empty.");
        }
        return value.trim();
    }

    // ── Passport format: 1-2 letters + 6-7 digits  e.g. A1234567 ──
    public static String validatePassportNumber(String passport) {
        if (isNullOrEmpty(passport))
            throw new IllegalArgumentException("ERROR: Passport number cannot be empty.");
        if (!passport.matches("[A-Z]{1,2}[0-9]{6,7}"))
            throw new IllegalArgumentException(
                    "ERROR: Invalid passport format '" + passport + "'. Expected: 1-2 letters + 6-7 digits (e.g. AB1234567).");
        return passport;
    }

    // ── Flight ID: FL + 3 digits  e.g. FL001 ──────────────────────
    public static String validateFlightId(String flightId) {
        if (isNullOrEmpty(flightId))
            throw new IllegalArgumentException("ERROR: Flight ID cannot be empty.");
        if (!flightId.matches("FL[0-9]{3}"))
            throw new IllegalArgumentException(
                    "ERROR: Invalid Flight ID '" + flightId + "'. Expected format: FL### (e.g. FL001).");
        return flightId;
    }

    // ── Seat: letter + 1-2 digits  e.g. A1, B12 ──────────────────
    public static String validateSeatNumber(String seat) {
        if (isNullOrEmpty(seat))
            throw new IllegalArgumentException("ERROR: Seat number cannot be empty.");
        if (!seat.matches("[A-Z][0-9]{1,2}"))
            throw new IllegalArgumentException(
                    "ERROR: Invalid seat '" + seat + "'. Expected format: letter + number (e.g. A1, B12).");
        return seat;
    }

    // ── Phone: 10-15 digits, optional leading + ───────────────────
    public static String validatePhone(String phone) {
        if (isNullOrEmpty(phone))
            throw new IllegalArgumentException("ERROR: Phone number cannot be empty.");
        if (!phone.matches("\\+?[0-9]{10,15}"))
            throw new IllegalArgumentException(
                    "ERROR: Invalid phone number '" + phone + "'. Expected 10-15 digits.");
        return phone;
    }

    // ── Positive number ───────────────────────────────────────────
    public static double validatePositiveDouble(String value, String fieldName) {
        if (isNullOrEmpty(value))
            throw new IllegalArgumentException("ERROR: '" + fieldName + "' cannot be empty.");
        try {
            double d = Double.parseDouble(value.trim());
            if (d <= 0) throw new IllegalArgumentException("ERROR: '" + fieldName + "' must be a positive number.");
            return d;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("ERROR: '" + fieldName + "' must be a valid number, got: '" + value + "'.");
        }
    }

    public static int validatePositiveInt(String value, String fieldName) {
        if (isNullOrEmpty(value))
            throw new IllegalArgumentException("ERROR: '" + fieldName + "' cannot be empty.");
        try {
            int i = Integer.parseInt(value.trim());
            if (i <= 0) throw new IllegalArgumentException("ERROR: '" + fieldName + "' must be a positive integer.");
            return i;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("ERROR: '" + fieldName + "' must be a valid integer, got: '" + value + "'.");
        }
    }

    // ── Class type ────────────────────────────────────────────────
    public static String validateClassType(String classType) {
        if (isNullOrEmpty(classType))
            throw new IllegalArgumentException("ERROR: Class type cannot be empty.");
        return switch (classType.trim().toUpperCase()) {
            case "1", "ECONOMY"  -> "ECONOMY";
            case "2", "BUSINESS" -> "BUSINESS";
            case "3", "FIRST"    -> "FIRST";
            default -> throw new IllegalArgumentException(
                    "ERROR: Invalid class type '" + classType + "'. Choose: 1-Economy, 2-Business, 3-First.");
        };
    }

    // ── Flight type ───────────────────────────────────────────────
    public static String validateFlightChoice(String choice, int max) {
        if (isNullOrEmpty(choice))
            throw new IllegalArgumentException("ERROR: Flight selection cannot be empty.");
        try {
            int i = Integer.parseInt(choice.trim());
            if (i < 1 || i > max)
                throw new IllegalArgumentException("ERROR: Please choose a flight number between 1 and " + max + ".");
            return choice.trim();
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("ERROR: Please enter a valid number for flight selection.");
        }
    }

    // ── Payment method ────────────────────────────────────────────
    public static String validatePaymentMethod(String method) {
        if (isNullOrEmpty(method))
            throw new IllegalArgumentException("ERROR: Payment method cannot be empty.");
        return switch (method.trim().toUpperCase()) {
            case "1", "CREDIT_CARD", "CREDIT"   -> "CREDIT_CARD";
            case "2", "DEBIT_CARD",  "DEBIT"    -> "DEBIT_CARD";
            case "3", "CASH"                    -> "CASH";
            case "4", "BANK_TRANSFER", "BANK"   -> "BANK_TRANSFER";
            case "5", "MOBILE_MONEY", "MOBILE"  -> "MOBILE_MONEY";
            default -> throw new IllegalArgumentException(
                    "ERROR: Invalid payment method. Choose: 1-Credit Card, 2-Debit Card, 3-Cash, 4-Bank Transfer, 5-Mobile Money.");
        };
    }

    // ── Nationality / Name (letters, spaces, hyphens) ─────────────
    public static String validateName(String name, String fieldName) {
        if (isNullOrEmpty(name))
            throw new IllegalArgumentException("ERROR: '" + fieldName + "' cannot be empty.");
        if (!name.trim().matches("[A-Za-z\\s\\-'.]+"))
            throw new IllegalArgumentException(
                    "ERROR: '" + fieldName + "' must contain only letters, spaces, or hyphens.");
        return name.trim();
    }
}
