package airport.staff;

public class SecurityOfficer extends Staff {
    private int securityLevel; // 1-5

    public SecurityOfficer(String staffId, String name, double salary, int securityLevel) {
        super(staffId, name, "Security Officer", salary);
        this.securityLevel = Math.max(1, Math.min(5, securityLevel));
    }

    public int getSecurityLevel() { return securityLevel; }
    public void setSecurityLevel(int level) { this.securityLevel = Math.max(1, Math.min(5, level)); }

    @Override public String getRoleDetails() { return "Security Officer | Level: " + securityLevel + "/5"; }
    @Override public String toString() { return super.toString() + " | Security Level: " + securityLevel; }
}
