package airport.staff;

import java.util.List;
import java.util.ArrayList;

public class CabinCrew extends Staff {
    private List<String> languageSkills;

    public CabinCrew(String staffId, String name, double salary, List<String> languageSkills) {
        super(staffId, name, "Cabin Crew", salary);
        this.languageSkills = languageSkills != null ? languageSkills : new ArrayList<>();
    }

    public List<String> getLanguageSkills() { return languageSkills; }
    public void addLanguage(String lang) { languageSkills.add(lang); }

    @Override public String getRoleDetails() { return "Cabin Crew | Languages: " + languageSkills; }
    @Override public String toString() { return super.toString() + " | Languages: " + languageSkills; }
}
