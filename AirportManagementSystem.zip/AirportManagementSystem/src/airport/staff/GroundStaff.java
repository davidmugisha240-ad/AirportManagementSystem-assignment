package airport.staff;

public class GroundStaff extends Staff {
    private String department;

    public GroundStaff(String staffId, String name, double salary, String department) {
        super(staffId, name, "Ground Staff", salary);
        this.department = department;
    }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    @Override public String getRoleDetails() { return "Ground Staff | Department: " + department; }
    @Override public String toString() { return super.toString() + " | Department: " + department; }
}
