package airport.staff;

import java.util.List;

// ─── Pilot ────────────────────────────────────────────────────────
public class Pilot extends Staff {
    private int flightHours;

    public Pilot(String staffId, String name, double salary, int flightHours) {
        super(staffId, name, "Pilot", salary);
        this.flightHours = flightHours;
    }

    public int getFlightHours() { return flightHours; }
    public void setFlightHours(int flightHours) { this.flightHours = flightHours; }

    @Override public String getRoleDetails() { return "Pilot | Flight Hours: " + flightHours; }
    @Override public String toString() { return super.toString() + " | Flight Hours: " + flightHours; }
}
