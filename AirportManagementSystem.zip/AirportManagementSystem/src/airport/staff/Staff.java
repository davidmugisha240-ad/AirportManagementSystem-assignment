package airport.staff;

// ─── Staff base class ─────────────────────────────────────────────
public class Staff {
    private String staffId;
    private String name;
    private String role;
    private double salary;

    public Staff() {}

    public Staff(String staffId, String name, String role, double salary) {
        this.staffId = staffId;
        this.name = name;
        this.role = role;
        this.salary = salary;
    }

    public String getStaffId() { return staffId; }
    public void setStaffId(String staffId) { this.staffId = staffId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }

    public String getRoleDetails() { return "Staff Role: " + role; }

    @Override public String toString() {
        return String.format("[Staff] ID: %s | Name: %s | Role: %s | Salary: $%.2f",
                staffId, name, role, salary);
    }
}
